import random
print("****** Welcome to Stone Paper Scissor game ! ******")
print()
t=''' Enter no. of rounds :
      Press 1 for 3 Round game
      press 2 for 5 Round game
      Press 3 for 7 Round game
      '''
l=int(input(t))
print()
h=0
c=0
round=0
if(l==1):
    round=3
elif(l==2):
    round=5
elif(l==3):
    round=7
count=1
n=random.randint(1,3)
while(count<=round):
    z='''  
      Press 1 for ROCK
      press 2 for PAPER
      Press 3 for SCISSOR
      '''
    print("******** ROUND :", count,"********")
    print(z)

    x=int(input())
    print()
    
    if(x==1 and n==1):
        c+=1
        h+=1
        print("You chose Rock")
        print("Computer also chose Rock")
        print(" Round Tie!:")
        print("Score=",h,":",c)
        print()
        count+=1
    elif(x==1 and n==2):
        c+=1
        print("You chose Rock")
        print("Computer chose Paper")
        print("Computer Won This round:")
        print("Score=",h,":",c)
        print()
        count+=1
    elif(x==1 and n==3):
        h+=1
        print("You chose Rock")
        print("Computer chose Scissor")
        print("You Won This round:")
        print("Score=",h,":",c)
        print()
        count+=1
    elif(x==2 and n==1):
        h+=1
        print("You chose Paper")
        print("Computer chose Rock")
        print("You Won This round:")
        print("Score=",h,":",c)
        print()
        count+=1
    elif(x==2 and n==2):
        c+=1
        h+=1
        print("You chose Paper")
        print("Computer chose Paper")
        print("ROUND TIE:")
        print("Score=",h,":",c)
        print()
        count+=1
    elif(x==2 and n==3):
        c+=1
        print("You chose Paper")
        print("Computer chose Scissor")
        print("Computer Won This round:")
        print("Score=",h,":",c)
        print()
        count+=1
    elif(x==3 and n==1):
        c+=1
        print("You chose Scissor")
        print("Computer chose Rock")
        print("Computer Won This round:")
        print("Score=",h,":",c)
        print()
        count+=1
    elif(x==3 and n==2):
        h+=1
        print("You chose Scissor")
        print("Computer chose Paper")
        print("You Won This round:")
        print("Score=",h,":",c)
        print()
        count+=1
    elif(x==3 and n==3):
        c+=1
        print("You chose scissor")
        print("Computer chose scissor")
        print("Round Tie:")
        print("Score=",h,":",c)
        print()
        count+=1
else:
    if(h<c):
        print("Sorry! You Lose this Match")
    elif(h>c):
        print("Congrats! You Won this Match")
    else:
        print("Match Tie")





